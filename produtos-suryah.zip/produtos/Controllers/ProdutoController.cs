using Microsoft.AspNetCore.Mvc;
using produto.Models;

namespace produto.Controllers
{
    public class ProdutoController : Controller
    {


        public IActionResult Index()
        {

            var produtos = new List<Produto>{
                new Produto{
                    Id = 1,
                    Nome = "Laptop Pro 15",
                    Valor = 2999.00m,
                    Cat = "Tecnologia",
                    Desc = "Um laptop potente para profissionais exigentes, com desempenho superior e tela 4K.",
                    Status = "Seu pedido esta em separação",
                    Data = "02/06/2024",
                    Responsavel = "Um laptop potente para profissionais exigentes, com desempenho superior e tela 4K."
                },
                new Produto{
                    Id = 2,
                    Nome = "Perfume Calvin Klein Euphoria 100ml",
                    Valor = 359.99m,
                    Cat = "Perfumaria",
                    Desc = "Euphoria é um perfume Calvin Klein feminino floral oriental. Extremamente marcante, traz uma fragrância sensual, luxuosa e sofisticada para a mulher ousada e confiante.",
                    Status = "Seu pedido saiu para entrega",
                    Data = "07/07/2024",
                    Responsavel = "Um laptop potente para profissionais exigentes, com desempenho superior e tela 4K."
                }
            };


            return View(produtos);
        }
    }
}
