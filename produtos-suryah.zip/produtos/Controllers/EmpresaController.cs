using Microsoft.AspNetCore.Mvc;
using empresa.Models;

namespace empresa.Controllers
{
    public class EmpresaController : Controller
    {


        public IActionResult Index()
        {

            var empresas = new List<Empresa>{
                new Empresa{
                    Id = 1,
                    Nome = "TechGenie Ltda.",
                    Endereço = "Avenida do Futuro, 202, Rio de Janeiro - RJ",
                    Desconto = "12%",
                    RegimeF = "Lucro Presumido",
                    Cnpj = "01.234.567/0001-89"
                },
                new Empresa{
                    Id = 2,
                    Nome= "Luxo Fragrâncias",
                    Endereço = "Avenida dos Perfumes, 654, Rio de Janeiro - RJ",
                    Desconto = "15%",
                    RegimeF = "Lucro Real",
                    Cnpj = "78.901.234/0001-56"
                }
            };


            return View(empresas);
        }
    }
}
