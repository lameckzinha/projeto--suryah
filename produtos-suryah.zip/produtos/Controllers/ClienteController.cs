using Microsoft.AspNetCore.Mvc;
using cliente.Models;

namespace cliente.Controllers
{
    public class ClienteController : Controller
    {


        public IActionResult Index()
        {

            var clientes = new List<Cliente>{
                new Cliente{
                    Id = 1,
                    Nome = "Carlos Oliveira",
                    Cpf = "45678901234",
                    Endereço = "Praça Central, 101",
                    Telefone = "41954321000",
                    Email = "carlos.oliveira@gmail.com"
                },
                new Cliente{
                    Id = 2,
                    Nome = "Laura Martins",
                    Cpf = "56789012345",
                    Endereço = "Rua da Paz, 202",
                    Telefone = "51943210987",
                    Email = "laura.martins@hotmail.com"
                }
            };


            return View(clientes);
        }
    }
}
